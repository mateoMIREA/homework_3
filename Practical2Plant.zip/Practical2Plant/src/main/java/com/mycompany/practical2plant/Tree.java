/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical2plant;

/**
 *
 * @author М_З_А
 */
public class Tree extends Plant {
    private String type;
    private double height;

    public Tree(String type, double height, String name, int age, String area) {
        super(name, age, area);
        this.type = type;
        this.height = height;
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height <= 0){
        System.out.println("Введены неверные данные");}
        else{
        this.height = height;}
    }
    
    
    
}
