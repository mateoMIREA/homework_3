/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical2plant;

/**
 *
 * @author М_З_А
 */
public class SmallPlant extends Plant{
    private double rootLength;
    private String climateZone;

    public SmallPlant(double rootLength, String climateZone, String name, int age, String area) {
        super(name, age, area);
        this.rootLength = rootLength;
        this.climateZone = climateZone;
    }

    public double getRootLength() {
        return rootLength;
    }

    public void setRootLength(double rootLength) {
        if (rootLength <= 0){
        System.out.println("Введены неверные данные");}
        else{
        this.rootLength = rootLength;}
    }

    public String getClimateZone() {
        return climateZone;
    }

    public void setClimateZone(String climateZone) {
        this.climateZone = climateZone;
    }
    
    
    
}
