/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical2plant;

/**
 *
 * @author М_З_А
 */
public class Gardener {
    public void change(Plant plant){
    String newName = plant.getName();
    String newName2 = newName.replaceAll("а","");
    String newName3 = newName2.replaceAll("у","");
    String newName4 = newName3.replaceAll("о","");
    String newName5 = newName4.replaceAll("и","");
    String newName6 = newName5.replaceAll("э","");
    String newName7 = newName6.replaceAll("ы","");
    String newName8 = newName7.replaceAll("я","");
    String newName9 = newName8.replaceAll("ю","");
    String newName10 = newName9.replaceAll("е","");
    String newName11 = newName10.replaceAll("ё","");
    String newName12 = newName11 + "VGTBL";
    plant.setName(newName12);
    }
}
